export const firebaseConfig = {
  "projectId": "studio-8584396786-7dc19",
  "appId": "1:780972257195:web:455493d0f8b2cce76f2cee",
  "apiKey": "AIzaSyDoNSSmFbtn2YQZxtGcM6OAttgC9DO5aqk",
  "authDomain": "studio-8584396786-7dc19.firebaseapp.com",
  "measurementId": "",
  "messagingSenderId": "780972257195"
};
