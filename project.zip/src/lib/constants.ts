export const CONDITION_COLORS: Record<string, string> = {
  "Like New": "text-green-400 border-green-900/50 bg-green-900/20",
  "Good": "text-amber-400 border-amber-900/50 bg-amber-900/20",
  "Fair": "text-rose-400 border-rose-900/50 bg-rose-900/20",
};

export const SUBJECTS = [
  "Physics",
  "Maths",
  "Chemistry",
  "Biology",
  "English",
  "Aptitude",
  "General Knowledge"
];

export const AREAS = [
  "Talwandi",
  "Vigyan Nagar",
  "Rajeev Gandhi Nagar",
  "Indraprastha Industrial Area",
  "Kunhari",
  "Landmark City",
  "Jawahar Nagar"
];
