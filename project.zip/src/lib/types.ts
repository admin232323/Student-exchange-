export type BookCondition = 'Like New' | 'Good' | 'Fair';

export interface Book {
  id: string;
  title: string;
  subject: string;
  price: number;
  originalPrice: number;
  seller: string;
  sellerId: string;
  sellerPhone: string;
  institute: string;
  condition: BookCondition;
  city: string;
  area: string;
  tags: string[];
  imageUrl: string;
  postedAt: any;
  description?: string;
}

export interface ChatMessage {
  id: string;
  text: string;
  senderId: string;
  senderName: string;
  createdAt: any;
}

export type TabType = 'browse' | 'wishlist' | 'mybooks' | 'profile';
