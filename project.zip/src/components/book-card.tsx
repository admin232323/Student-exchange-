import React from 'react';
import Image from 'next/image';
import { Book } from '@/lib/types';
import { CONDITION_COLORS } from '@/lib/constants';
import { Heart, MapPin } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';

interface BookCardProps {
  book: Book;
  isWishlisted: boolean;
  onToggleWishlist: (e: React.MouseEvent) => void;
  onClick: () => void;
}

export function BookCard({ book, isWishlisted, onToggleWishlist, onClick }: BookCardProps) {
  const savingsPercent = book.originalPrice > book.price 
    ? Math.round((1 - book.price / book.originalPrice) * 100) 
    : 0;

  return (
    <div
      onClick={onClick}
      className="group bg-card border border-border rounded-2xl p-0 transition-all duration-300 hover:border-primary/50 hover:shadow-lg hover:shadow-primary/5 cursor-pointer relative overflow-hidden flex flex-col h-full"
    >
      <div className="relative aspect-[4/5] w-full overflow-hidden">
        <Image 
          src={book.imageUrl || 'https://picsum.photos/seed/book/400/500'} 
          alt={book.title}
          fill
          className="object-cover transition-transform duration-500 group-hover:scale-105"
          data-ai-hint="book cover"
        />
        <div className="absolute top-2 right-2 z-10">
          <button
            onClick={onToggleWishlist}
            className="p-1.5 rounded-full bg-background/80 backdrop-blur-sm hover:bg-background transition-colors shadow-sm"
          >
            <Heart
              className={cn(
                "w-4 h-4 transition-colors",
                isWishlisted ? "fill-primary text-primary" : "text-muted-foreground"
              )}
            />
          </button>
        </div>
        {savingsPercent > 0 && (
          <div className="absolute bottom-2 left-2 bg-green-500 text-white text-[10px] font-black px-2 py-0.5 rounded-md shadow-lg">
            -{savingsPercent}% OFF
          </div>
        )}
      </div>

      <div className="p-4 flex-1 flex flex-col">
        <h3 className="font-headline font-bold text-sm leading-tight mb-1 line-clamp-1 group-hover:text-primary transition-colors">
          {book.title}
        </h3>
        <p className="text-[10px] text-muted-foreground font-bold uppercase tracking-wider mb-2">
          {book.seller} • {book.institute}
        </p>

        <div className="flex flex-wrap gap-1.5 mb-3">
          <Badge
            variant="outline"
            className={cn("text-[8px] h-4 px-1 py-0 font-bold", CONDITION_COLORS[book.condition] || "text-muted-foreground")}
          >
            {book.condition}
          </Badge>
        </div>

        <div className="mt-auto flex items-center justify-between">
          <div className="flex flex-col">
            <span className="text-base font-black text-primary leading-none">₹{book.price}</span>
            {book.originalPrice > book.price && (
              <span className="text-[10px] text-muted-foreground line-through opacity-60">₹{book.originalPrice}</span>
            )}
          </div>
          <div className="flex items-center gap-0.5 text-[9px] text-muted-foreground font-bold">
            <MapPin className="w-2.5 h-2.5" />
            <span className="truncate max-w-[60px]">{book.area}</span>
          </div>
        </div>
      </div>
    </div>
  );
}
