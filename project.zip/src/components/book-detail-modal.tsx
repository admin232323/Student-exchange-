import React from 'react';
import Image from 'next/image';
import { Book } from '@/lib/types';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { CONDITION_COLORS } from '@/lib/constants';
import { Heart, MapPin, Phone, MessageCircle, Info, User, Share2 } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Badge } from '@/components/ui/badge';
import { useUser } from '@/firebase';

interface BookDetailModalProps {
  book: Book | null;
  onClose: () => void;
  isWishlisted: boolean;
  onToggleWishlist: (id: string) => void;
  onChat: (book: Book) => void;
  onCall: (book: Book) => void;
}

export function BookDetailModal({ book, onClose, isWishlisted, onToggleWishlist, onChat, onCall }: BookDetailModalProps) {
  const { user } = useUser();
  if (!book) return null;

  const isOwnBook = user?.uid === book.sellerId;

  return (
    <Dialog open={!!book} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="sm:max-w-[480px] p-0 overflow-hidden bg-card border-border rounded-3xl">
        <div className="custom-scrollbar max-h-[90vh] overflow-y-auto">
          <div className="relative aspect-video w-full overflow-hidden">
            <Image 
              src={book.imageUrl || 'https://picsum.photos/seed/book/800/400'} 
              alt={book.title}
              fill
              className="object-cover"
              data-ai-hint="book cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
            <div className="absolute top-4 left-4 flex gap-2">
              <Badge variant="secondary" className="bg-primary text-white border-none font-bold">
                {book.subject}
              </Badge>
            </div>
            {!isOwnBook && (
              <button
                onClick={() => onToggleWishlist(book.id)}
                className="absolute top-4 right-4 p-2.5 rounded-full bg-white/20 backdrop-blur-md hover:bg-white/30 transition-colors"
              >
                <Heart
                  className={cn(
                    "w-6 h-6 transition-colors",
                    isWishlisted ? "fill-primary text-primary" : "text-white"
                  )}
                />
              </button>
            )}
          </div>

          <div className="p-6">
            <DialogHeader className="text-left mb-6">
              <div className="flex justify-between items-start gap-4">
                <div>
                  <DialogTitle className="font-headline text-2xl font-bold mb-1 leading-tight">
                    {book.title}
                  </DialogTitle>
                  <p className="text-xs text-muted-foreground font-bold uppercase tracking-widest flex items-center gap-1">
                    <MapPin className="w-3 h-3 text-primary" /> {book.area}, Kota
                  </p>
                </div>
                <div className="text-right shrink-0">
                  <p className="text-2xl font-black text-primary leading-none">₹{book.price}</p>
                  {book.originalPrice > book.price && (
                    <p className="text-[10px] text-muted-foreground line-through mt-1 opacity-70">₹{book.originalPrice}</p>
                  )}
                </div>
              </div>
            </DialogHeader>

            <div className="flex gap-2 mb-8">
              <Badge variant="outline" className={cn("px-4 py-1.5 border-none font-bold text-xs rounded-lg shadow-sm", CONDITION_COLORS[book.condition] || "bg-muted text-muted-foreground")}>
                Condition: {book.condition}
              </Badge>
            </div>

            <div className="space-y-6">
              <div className="bg-muted/20 rounded-2xl p-5 border border-border">
                <p className="text-[10px] uppercase tracking-widest text-muted-foreground mb-4 font-black">Seller Contact Details</p>
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-2xl bg-primary/10 flex items-center justify-center text-primary border border-primary/20">
                    <User className="w-6 h-6" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-bold text-lg leading-none mb-1 truncate">{book.seller}</p>
                    <p className="text-xs text-muted-foreground truncate">{book.institute}</p>
                  </div>
                </div>
              </div>

              {book.description && (
                <div className="space-y-2">
                  <p className="text-[10px] uppercase tracking-widest text-muted-foreground font-black flex items-center gap-1.5 px-1">
                    <Info className="w-3.5 h-3.5" /> Book Details
                  </p>
                  <div className="bg-muted/10 rounded-2xl p-4 border border-border/50">
                    <p className="text-sm text-foreground/80 leading-relaxed whitespace-pre-wrap italic">
                      "{book.description}"
                    </p>
                  </div>
                </div>
              )}

              {!isOwnBook && (
                <div className="grid grid-cols-2 gap-4 pt-4">
                  <Button
                    variant="outline"
                    className="rounded-2xl h-14 font-black flex gap-2 border-primary/20 hover:bg-primary/5 text-primary"
                    onClick={() => onChat(book)}
                  >
                    <MessageCircle className="w-5 h-5" /> Chat Now
                  </Button>
                  <Button
                    className="rounded-2xl h-14 font-black flex gap-2 bg-primary hover:bg-primary/90 text-white shadow-lg shadow-primary/20"
                    onClick={() => onCall(book)}
                  >
                    <Phone className="w-5 h-5" /> Call Seller
                  </Button>
                </div>
              )}
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
