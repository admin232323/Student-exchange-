import React, { useState } from 'react';
import Image from 'next/image';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { BookCondition } from '@/lib/types';
import { Sparkles, Loader2, BookOpen, ImageIcon, RefreshCw } from 'lucide-react';
import { generateBookDescription } from '@/ai/flows/ai-generated-book-description';
import { useUser, useFirestore } from '@/firebase';
import { collection, doc, serverTimestamp } from 'firebase/firestore';
import { setDocumentNonBlocking } from '@/firebase/non-blocking-updates';
import { useToast } from '@/hooks/use-toast';
import { SUBJECTS, AREAS } from '@/lib/constants';

interface SellBookModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: () => void;
}

export function SellBookModal({ isOpen, onClose, onSubmit }: SellBookModalProps) {
  const { user } = useUser();
  const db = useFirestore();
  const { toast } = useToast();
  const [aiLoading, setAiLoading] = useState(false);
  const [formData, setFormData] = useState({
    title: '',
    subject: SUBJECTS[0],
    price: '',
    originalPrice: '',
    phone: '',
    condition: 'Good' as BookCondition,
    institute: '',
    area: AREAS[0],
    description: '',
    imageUrl: '',
  });

  const handleGenerateDescription = async () => {
    if (!formData.title) {
      toast({ title: "Title Required", description: "Please enter a book title first.", variant: "destructive" });
      return;
    }
    setAiLoading(true);
    try {
      const result = await generateBookDescription({
        title: formData.title,
        subject: formData.subject,
      });
      setFormData(prev => ({ ...prev, description: result.description }));
      toast({ title: "AI Description Ready", description: "Your listing just got a professional touch." });
    } catch (error) {
      toast({ title: "AI Unavailable", description: "Couldn't generate description right now.", variant: "destructive" });
    } finally {
      setAiLoading(false);
    }
  };

  const setRandomPlaceholder = () => {
    const seed = Math.floor(Math.random() * 1000);
    setFormData(prev => ({ ...prev, imageUrl: `https://picsum.photos/seed/${seed}/400/500` }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.title || !formData.price || !formData.phone || !user || !db) {
      toast({ title: "Incomplete Form", description: "Please fill in all required (*) fields.", variant: "destructive" });
      return;
    }
    
    // Proper way to get a new doc ID
    const bookRef = doc(collection(db, 'books'));
    const bookId = bookRef.id;

    const bookData = {
      id: bookId,
      title: formData.title,
      subject: formData.subject,
      price: Number(formData.price),
      originalPrice: Number(formData.originalPrice) || Number(formData.price),
      sellerPhone: formData.phone,
      condition: formData.condition,
      institute: formData.institute || 'Independent Student',
      area: formData.area,
      description: formData.description,
      imageUrl: formData.imageUrl || `https://picsum.photos/seed/${bookId}/400/500`,
      seller: user.displayName || 'Kota Student',
      sellerId: user.uid,
      city: 'Kota',
      tags: [formData.subject],
      postedAt: serverTimestamp(),
    };

    setDocumentNonBlocking(bookRef, bookData, { merge: true });
    
    toast({
      title: "Successfully Listed!",
      description: "Students in Kota can now see your book.",
    });

    setFormData({
      title: '',
      subject: SUBJECTS[0],
      price: '',
      originalPrice: '',
      phone: '',
      condition: 'Good',
      institute: '',
      area: AREAS[0],
      description: '',
      imageUrl: '',
    });
    
    onSubmit();
  };

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="sm:max-w-[500px] p-0 overflow-hidden bg-card border-border rounded-3xl">
        <div className="p-6 custom-scrollbar max-h-[90vh] overflow-y-auto">
          <DialogHeader className="mb-6">
            <div className="flex items-center gap-2 mb-2">
              <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center text-primary">
                <BookOpen className="w-5 h-5" />
              </div>
              <DialogTitle className="font-headline text-2xl font-black">Post Your Book</DialogTitle>
            </div>
            <p className="text-sm text-muted-foreground">Sell directly to fellow students in Kota.</p>
          </DialogHeader>

          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="space-y-2">
              <Label className="text-[10px] font-black uppercase tracking-widest text-muted-foreground ml-1">Product Image</Label>
              <div className="flex gap-4 items-center">
                <div className="relative w-24 h-32 rounded-2xl bg-muted border border-border overflow-hidden shrink-0 flex items-center justify-center">
                  {formData.imageUrl ? (
                    <Image src={formData.imageUrl} alt="Preview" fill className="object-cover" />
                  ) : (
                    <ImageIcon className="w-8 h-8 text-muted-foreground/30" />
                  )}
                </div>
                <div className="flex-1 space-y-2">
                  <Input
                    placeholder="Paste Image URL..."
                    className="rounded-xl h-10 text-xs"
                    value={formData.imageUrl}
                    onChange={e => setFormData(prev => ({ ...prev, imageUrl: e.target.value }))}
                  />
                  <Button 
                    type="button" 
                    variant="ghost" 
                    size="sm" 
                    className="text-[10px] font-bold gap-2 text-primary hover:bg-primary/5"
                    onClick={setRandomPlaceholder}
                  >
                    <RefreshCw className="w-3 h-3" /> Generate Random Placeholder
                  </Button>
                </div>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="title" className="text-[10px] font-black uppercase tracking-widest text-muted-foreground ml-1">Book Title *</Label>
              <Input
                id="title"
                placeholder="e.g. HC Verma Concepts of Physics"
                className="rounded-xl h-12 bg-muted/30 border-border"
                value={formData.title}
                onChange={e => setFormData(prev => ({ ...prev, title: e.target.value }))}
                required
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label className="text-[10px] font-black uppercase tracking-widest text-muted-foreground ml-1">Category</Label>
                <Select value={formData.subject} onValueChange={(v) => setFormData(p => ({ ...p, subject: v }))}>
                  <SelectTrigger className="rounded-xl h-12 bg-muted/30">
                    <SelectValue placeholder="Select Subject" />
                  </SelectTrigger>
                  <SelectContent>
                    {SUBJECTS.map(s => <SelectItem key={s} value={s}>{s}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label className="text-[10px] font-black uppercase tracking-widest text-muted-foreground ml-1">Book Condition</Label>
                <Select value={formData.condition} onValueChange={(v) => setFormData(p => ({ ...p, condition: v as BookCondition }))}>
                  <SelectTrigger className="rounded-xl h-12 bg-muted/30">
                    <SelectValue placeholder="Condition" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Like New">Like New</SelectItem>
                    <SelectItem value="Good">Good</SelectItem>
                    <SelectItem value="Fair">Fair</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="price" className="text-[10px] font-black uppercase tracking-widest text-muted-foreground ml-1">Your Price (₹) *</Label>
                <Input
                  id="price"
                  type="number"
                  className="rounded-xl h-12 bg-muted/30"
                  value={formData.price}
                  onChange={e => setFormData(prev => ({ ...prev, price: e.target.value }))}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="originalPrice" className="text-[10px] font-black uppercase tracking-widest text-muted-foreground ml-1">Original MRP (₹)</Label>
                <Input
                  id="originalPrice"
                  type="number"
                  className="rounded-xl h-12 bg-muted/30"
                  value={formData.originalPrice}
                  onChange={e => setFormData(prev => ({ ...prev, originalPrice: e.target.value }))}
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="phone" className="text-[10px] font-black uppercase tracking-widest text-muted-foreground ml-1">WhatsApp/Phone *</Label>
                <Input
                  id="phone"
                  placeholder="For buyer to contact"
                  className="rounded-xl h-12 bg-muted/30"
                  value={formData.phone}
                  onChange={e => setFormData(prev => ({ ...prev, phone: e.target.value }))}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label className="text-[10px] font-black uppercase tracking-widest text-muted-foreground ml-1">Pickup Area</Label>
                <Select value={formData.area} onValueChange={(v) => setFormData(p => ({ ...p, area: v }))}>
                  <SelectTrigger className="rounded-xl h-12 bg-muted/30">
                    <SelectValue placeholder="Select Area" />
                  </SelectTrigger>
                  <SelectContent>
                    {AREAS.map(a => <SelectItem key={a} value={a}>{a}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="space-y-2">
              <div className="flex justify-between items-center px-1">
                <Label className="text-[10px] font-black uppercase tracking-widest text-muted-foreground">Short Description</Label>
                <Button
                  type="button"
                  variant="ghost"
                  size="sm"
                  className="h-7 rounded-lg text-[10px] text-primary font-black gap-1 hover:bg-primary/10"
                  onClick={handleGenerateDescription}
                  disabled={aiLoading}
                >
                  {aiLoading ? <Loader2 className="w-3 h-3 animate-spin" /> : <Sparkles className="w-3 h-3" />}
                  AI Enhance
                </Button>
              </div>
              <Textarea
                placeholder="Mention highlights like 'No markings', 'Latest edition', etc."
                className="rounded-xl min-h-[80px] bg-muted/30 resize-none"
                value={formData.description}
                onChange={e => setFormData(prev => ({ ...prev, description: e.target.value }))}
              />
            </div>

            <Button type="submit" className="w-full rounded-2xl h-14 font-black text-lg shadow-xl shadow-primary/30 bg-primary hover:bg-primary/90 text-white">
              Launch Listing
            </Button>
          </form>
        </div>
      </DialogContent>
    </Dialog>
  );
}
