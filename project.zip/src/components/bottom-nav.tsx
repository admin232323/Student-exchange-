import React from 'react';
import { TabType } from '@/lib/types';
import { Store, Heart, Package, User } from 'lucide-react';
import { cn } from '@/lib/utils';

interface BottomNavProps {
  activeTab: TabType;
  onTabChange: (tab: TabType) => void;
}

export function BottomNav({ activeTab, onTabChange }: BottomNavProps) {
  const tabs: { id: TabType; icon: React.ElementType; label: string }[] = [
    { id: 'browse', icon: Store, label: 'Market' },
    { id: 'wishlist', icon: Heart, label: 'Saved' },
    { id: 'mybooks', icon: Package, label: 'My Books' },
    { id: 'profile', icon: User, label: 'Profile' },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-card/80 backdrop-blur-lg border-t border-border px-6 py-3 pb-8 z-50">
      <div className="max-w-md mx-auto flex justify-between items-center">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            onClick={() => onTabChange(tab.id)}
            className="flex flex-col items-center gap-1 transition-all"
          >
            <tab.icon
              className={cn(
                "w-6 h-6 transition-colors",
                activeTab === tab.id ? "text-primary fill-primary/10" : "text-muted-foreground"
              )}
            />
            <span
              className={cn(
                "text-[10px] font-bold uppercase tracking-wider transition-colors",
                activeTab === tab.id ? "text-primary" : "text-muted-foreground"
              )}
            >
              {tab.label}
            </span>
          </button>
        ))}
      </div>
    </nav>
  );
}