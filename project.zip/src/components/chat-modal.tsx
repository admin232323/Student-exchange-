
'use client';

import React, { useState, useMemo } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Book, ChatMessage } from '@/lib/types';
import { Send, MapPin, ShieldCheck, User, Loader2 } from 'lucide-react';
import { useUser, useFirestore, useCollection, useMemoFirebase } from '@/firebase';
import { collection, doc, serverTimestamp, query, orderBy } from 'firebase/firestore';
import { setDocumentNonBlocking } from '@/firebase/non-blocking-updates';

interface ChatModalProps {
  book: Book | null;
  isOpen: boolean;
  onClose: () => void;
}

export function ChatModal({ book, isOpen, onClose }: ChatModalProps) {
  const { user } = useUser();
  const db = useFirestore();
  const [input, setInput] = useState('');

  // Consistent chat ID: bookId + sorted UIDs
  const chatId = useMemo(() => {
    if (!book || !user) return null;
    const participants = [user.uid, book.sellerId].sort();
    return `${book.id}_${participants.join('_')}`;
  }, [book, user]);

  const messagesQuery = useMemoFirebase(() => {
    if (!db || !chatId) return null;
    return query(collection(db, 'chats', chatId, 'messages'), orderBy('createdAt', 'asc'));
  }, [db, chatId]);

  const { data: messages, isLoading } = useCollection<ChatMessage>(messagesQuery);

  const handleSend = () => {
    if (!input.trim() || !user || !db || !chatId) return;

    const messageId = doc(collection(db, 'chats', chatId, 'messages')).id;
    const messageRef = doc(db, 'chats', chatId, 'messages', messageId);

    const messageData = {
      id: messageId,
      text: input,
      senderId: user.uid,
      senderName: user.displayName || 'Student',
      createdAt: serverTimestamp(),
    };

    setDocumentNonBlocking(messageRef, messageData, { merge: true });
    setInput('');
  };

  if (!book || !user) return null;

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="sm:max-w-[450px] p-0 overflow-hidden bg-card border-border rounded-3xl h-[600px] flex flex-col">
        <DialogHeader className="p-4 border-b border-border bg-muted/20">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center text-primary">
              <User className="w-5 h-5" />
            </div>
            <div>
              <DialogTitle className="text-base font-bold">
                {book.sellerId === user.uid ? 'Buyer Inquiry' : book.seller}
              </DialogTitle>
              <p className="text-[10px] text-muted-foreground flex items-center gap-1">
                <MapPin className="w-2.5 h-2.5" /> {book.area}, Kota
              </p>
            </div>
          </div>
        </DialogHeader>

        <div className="p-3 bg-accent/30 border-b border-border flex items-center gap-3">
          <span className="text-2xl">{book.emoji}</span>
          <div className="flex-1 min-w-0">
            <p className="text-xs font-bold truncate">{book.title}</p>
            <p className="text-[10px] text-primary font-bold">₹{book.price}</p>
          </div>
        </div>

        <div className="flex-1 overflow-y-auto p-4 space-y-4 custom-scrollbar">
          <div className="bg-muted/50 rounded-xl p-3 flex gap-3 items-start border border-border/50">
            <ShieldCheck className="w-4 h-4 text-green-500 shrink-0 mt-0.5" />
            <p className="text-[10px] text-muted-foreground leading-relaxed">
              Safety Tip: Meet in public campus areas. Inspect the book before payment. No online transfers!
            </p>
          </div>

          {isLoading ? (
            <div className="flex justify-center py-4">
              <Loader2 className="w-6 h-6 animate-spin text-primary" />
            </div>
          ) : (
            messages?.map((m) => (
              <div
                key={m.id}
                className={`flex ${m.senderId === user.uid ? 'justify-end' : 'justify-start'}`}
              >
                <div
                  className={`max-w-[80%] rounded-2xl px-4 py-2.5 text-sm ${
                    m.senderId === user.uid
                      ? 'bg-primary text-white rounded-tr-none'
                      : 'bg-muted text-foreground rounded-tl-none border border-border'
                  }`}
                >
                  {m.text}
                </div>
              </div>
            ))
          )}
        </div>

        <div className="p-4 border-t border-border bg-background">
          <div className="flex gap-2">
            <Input
              placeholder="Ask about the condition..."
              className="rounded-xl bg-muted border-none h-11"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSend()}
            />
            <Button
              size="icon"
              className="rounded-xl h-11 w-11 bg-primary shrink-0"
              onClick={handleSend}
            >
              <Send className="w-5 h-5 text-white" />
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
