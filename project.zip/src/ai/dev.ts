import { config } from 'dotenv';
config();

import '@/ai/flows/ai-generated-book-description.ts';