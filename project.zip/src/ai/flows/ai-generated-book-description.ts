'use server';
/**
 * @fileOverview A Genkit flow for generating concise and engaging book descriptions.
 *
 * - generateBookDescription - A function that generates a book description based on its title and subject.
 * - AIGeneratedBookDescriptionInput - The input type for the generateBookDescription function.
 * - AIGeneratedBookDescriptionOutput - The return type for the generateBookDescription function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const AIGeneratedBookDescriptionInputSchema = z.object({
  title: z.string().describe("The title of the book."),
  subject: z.string().describe("The subject of the book (e.g., 'Physics', 'Maths', 'Chemistry')."),
});
export type AIGeneratedBookDescriptionInput = z.infer<typeof AIGeneratedBookDescriptionInputSchema>;

const AIGeneratedBookDescriptionOutputSchema = z.object({
  description: z.string().describe("A concise and engaging description for the book."),
});
export type AIGeneratedBookDescriptionOutput = z.infer<typeof AIGeneratedBookDescriptionOutputSchema>;

export async function generateBookDescription(input: AIGeneratedBookDescriptionInput): Promise<AIGeneratedBookDescriptionOutput> {
  return aiGeneratedBookDescriptionFlow(input);
}

const aiGeneratedBookDescriptionPrompt = ai.definePrompt({
  name: 'aiGeneratedBookDescriptionPrompt',
  input: {schema: AIGeneratedBookDescriptionInputSchema},
  output: {schema: AIGeneratedBookDescriptionOutputSchema},
  prompt: `You are an expert copywriter for student books.
Generate a concise and engaging description for a book with the following details:

Book Title: {{{title}}}
Subject: {{{subject}}}

The description should be appealing to students, highlighting key benefits or content without being overly long. Focus on making it sound attractive for a quick sale. Keep it to a maximum of 50 words.`,
});

const aiGeneratedBookDescriptionFlow = ai.defineFlow(
  {
    name: 'aiGeneratedBookDescriptionFlow',
    inputSchema: AIGeneratedBookDescriptionInputSchema,
    outputSchema: AIGeneratedBookDescriptionOutputSchema,
  },
  async input => {
    const {output} = await aiGeneratedBookDescriptionPrompt(input);
    return output!;
  }
);
