"use client";

import React, { useState, useMemo, useEffect } from 'react';
import Image from 'next/image';
import { Book as BookType, TabType } from '@/lib/types';
import { BookCard } from '@/components/book-card';
import { BookDetailModal } from '@/components/book-detail-modal';
import { SellBookModal } from '@/components/sell-book-modal';
import { ChatModal } from '@/components/chat-modal';
import { BottomNav } from '@/components/bottom-nav';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Search, Plus, Sparkles, Loader2, Trash2, LogIn, UserCircle, Mail, Key, ArrowLeft, Store } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { useUser, useCollection, useFirestore, useAuth, useMemoFirebase } from '@/firebase';
import { collection, query, orderBy, doc, serverTimestamp } from 'firebase/firestore';
import { initiateGoogleSignIn, initiateAnonymousSignIn, initiateEmailSignIn, initiateEmailSignUp } from '@/firebase/non-blocking-login';
import { setDocumentNonBlocking, deleteDocumentNonBlocking } from '@/firebase/non-blocking-updates';

export default function StudentExchange() {
  const { user, isUserLoading } = useUser();
  const auth = useAuth();
  const db = useFirestore();
  const [activeTab, setActiveTab] = useState<TabType>('browse');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedBook, setSelectedBook] = useState<BookType | null>(null);
  const [isSellModalOpen, setIsSellModalOpen] = useState(false);
  const [isChatOpen, setIsChatOpen] = useState(false);
  
  // Auth Form State
  const [showEmailAuth, setShowEmailAuth] = useState(false);
  const [authMode, setAuthMode] = useState<'login' | 'signup'>('login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  
  const { toast } = useToast();

  useEffect(() => {
    if (user && db) {
      const userRef = doc(db, 'users', user.uid);
      setDocumentNonBlocking(userRef, {
        id: user.uid,
        name: user.displayName || 'Kota Student',
        email: user.email || 'guest@student.kota',
        profileImageUrl: user.photoURL || null,
        lastActive: serverTimestamp(),
        isAnonymous: user.isAnonymous,
      }, { merge: true });
    }
  }, [user, db]);

  const booksQuery = useMemoFirebase(() => {
    if (!db || !user) return null;
    return query(collection(db, 'books'), orderBy('postedAt', 'desc'));
  }, [db, user]);
  const { data: booksData, isLoading: isBooksLoading } = useCollection<BookType>(booksQuery);

  const wishlistQuery = useMemoFirebase(() => {
    if (!db || !user) return null;
    return collection(db, 'users', user.uid, 'wishlist_items');
  }, [db, user]);
  const { data: wishlistData } = useCollection<BookType>(wishlistQuery);

  const wishlistIds = useMemo(() => wishlistData?.map(item => item.id) || [], [wishlistData]);

  const filteredBooks = useMemo(() => {
    if (!booksData) return [];
    return booksData.filter(b => {
      const q = searchQuery.toLowerCase();
      return b.title.toLowerCase().includes(q) || 
             b.subject.toLowerCase().includes(q) ||
             b.area.toLowerCase().includes(q);
    });
  }, [booksData, searchQuery]);

  const toggleWishlist = (book: BookType) => {
    if (!user || !db) return;
    const isAlreadyWishlisted = wishlistIds.includes(book.id);
    const wishlistRef = doc(db, 'users', user.uid, 'wishlist_items', book.id);
    if (isAlreadyWishlisted) {
      deleteDocumentNonBlocking(wishlistRef);
    } else {
      setDocumentNonBlocking(wishlistRef, book, { merge: true });
      toast({ title: "Saved!", description: "Added to your wishlist." });
    }
  };

  const handleUnlist = (bookId: string) => {
    if (!db) return;
    deleteDocumentNonBlocking(doc(db, 'books', bookId));
    toast({ title: "Listing Removed", description: "Your book has been unlisted." });
  };

  const handleEmailAuth = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !password) return;
    
    if (authMode === 'login') {
      initiateEmailSignIn(auth, email, password);
    } else {
      initiateEmailSignUp(auth, email, password);
    }
  };

  if (isUserLoading) {
    return (
      <div className="h-screen flex items-center justify-center bg-background">
        <div className="flex flex-col items-center gap-4">
          <Loader2 className="w-10 h-10 animate-spin text-primary" />
          <p className="text-xs font-code text-muted-foreground animate-pulse uppercase tracking-widest">Verifying Identity...</p>
        </div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="max-w-md mx-auto h-screen flex flex-col items-center justify-center p-8 text-center gap-10">
        <div className="relative">
          <div className="w-28 h-28 bg-primary rounded-[2.5rem] flex items-center justify-center text-6xl shadow-2xl shadow-primary/40 animate-in zoom-in-50 duration-500">📚</div>
          <div className="absolute -bottom-2 -right-2 bg-background border-4 border-background rounded-full p-1.5 shadow-lg">
            <Sparkles className="w-6 h-6 text-primary fill-primary" />
          </div>
        </div>
        
        <div className="space-y-3">
          <h1 className="text-5xl font-black tracking-tighter">Student<span className="text-primary">Exchange</span></h1>
          <p className="text-muted-foreground leading-relaxed text-sm">
            The direct peer-to-peer marketplace for Kota students. Buy and sell books within your campus circle.
          </p>
        </div>
        
        <div className="w-full space-y-4">
          {!showEmailAuth ? (
            <>
              <Button 
                size="lg" 
                className="w-full rounded-2xl h-16 font-black gap-3 text-lg shadow-xl shadow-primary/20 hover:scale-[1.02] transition-all active:scale-95 bg-white text-black hover:bg-neutral-100 border border-neutral-200"
                onClick={() => initiateGoogleSignIn(auth)}
              >
                <svg className="w-6 h-6" viewBox="0 0 24 24">
                  <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
                  <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
                  <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l3.66-2.84z"/>
                  <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.66l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/>
                </svg>
                Continue with Gmail
              </Button>

              <Button 
                variant="outline"
                size="lg" 
                className="w-full rounded-2xl h-16 font-black gap-3 text-lg border-primary/20 hover:bg-primary/5 text-primary"
                onClick={() => setShowEmailAuth(true)}
              >
                <Mail className="w-6 h-6" />
                Login with Email
              </Button>
              
              <div className="relative py-2">
                <div className="absolute inset-0 flex items-center"><span className="w-full border-t border-muted" /></div>
                <div className="relative flex justify-center text-xs uppercase"><span className="bg-background px-2 text-muted-foreground font-bold">Or use fallback</span></div>
              </div>

              <Button 
                variant="ghost"
                size="lg" 
                className="w-full rounded-2xl h-14 font-bold gap-2 text-muted-foreground hover:text-foreground"
                onClick={() => initiateAnonymousSignIn(auth)}
              >
                <LogIn className="w-5 h-5" /> Continue as Guest
              </Button>
            </>
          ) : (
            <form onSubmit={handleEmailAuth} className="w-full space-y-4 animate-in slide-in-from-right-4 duration-300">
              <div className="flex items-center gap-2 mb-4">
                <Button 
                  type="button" 
                  variant="ghost" 
                  size="icon" 
                  onClick={() => setShowEmailAuth(false)}
                  className="rounded-full"
                >
                  <ArrowLeft className="w-5 h-5" />
                </Button>
                <h2 className="text-xl font-bold">{authMode === 'login' ? 'Welcome Back' : 'Join the Community'}</h2>
              </div>

              <div className="space-y-4 text-left">
                <div className="space-y-1">
                  <label className="text-xs font-bold uppercase tracking-widest text-muted-foreground ml-1">Email Address</label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                    <Input 
                      type="email"
                      placeholder="student@kota.edu" 
                      className="pl-10 h-12 rounded-xl bg-card border-border"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      required
                    />
                  </div>
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-bold uppercase tracking-widest text-muted-foreground ml-1">Password</label>
                  <div className="relative">
                    <Key className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                    <Input 
                      type="password"
                      placeholder="••••••••" 
                      className="pl-10 h-12 rounded-xl bg-card border-border"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      required
                    />
                  </div>
                </div>
              </div>

              <Button 
                type="submit"
                size="lg" 
                className="w-full rounded-2xl h-14 font-black text-lg shadow-xl shadow-primary/20 bg-primary text-white"
              >
                {authMode === 'login' ? 'Sign In' : 'Create Account'}
              </Button>

              <p className="text-sm text-muted-foreground">
                {authMode === 'login' ? "Don't have an account?" : "Already have an account?"}{' '}
                <button 
                  type="button"
                  className="text-primary font-bold hover:underline"
                  onClick={() => setAuthMode(authMode === 'login' ? 'signup' : 'login')}
                >
                  {authMode === 'login' ? 'Sign Up' : 'Log In'}
                </button>
              </p>
            </form>
          )}
        </div>

        <p className="text-[10px] text-muted-foreground uppercase font-bold tracking-widest mt-auto">Verified Campus Access Only</p>
      </div>
    );
  }

  return (
    <div className="max-w-2xl mx-auto min-h-screen flex flex-col relative pb-32">
      <div className="hero-glow" />

      <header className="sticky top-0 z-40 bg-background/80 backdrop-blur-md border-b border-border px-4 py-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-primary rounded-xl flex items-center justify-center text-2xl shadow-lg shadow-primary/20">📚</div>
          <div>
            <h1 className="font-headline font-black text-lg leading-tight tracking-tight">Student<span className="text-primary">Exchange</span></h1>
            <p className="text-[10px] text-muted-foreground font-code uppercase tracking-widest">Kota Hub</p>
          </div>
        </div>
        <Button 
          size="sm" 
          className="rounded-xl bg-primary hover:bg-primary/90 text-white font-bold gap-2 px-4 shadow-lg shadow-primary/10"
          onClick={() => setIsSellModalOpen(true)}
        >
          <Plus className="w-4 h-4" /> Sell Book
        </Button>
      </header>

      <main className="flex-1 px-4 pt-6 relative z-10">
        {activeTab === 'browse' && (
          <div className="space-y-6 animate-in fade-in slide-in-from-bottom-2 duration-500">
            <div className="space-y-2 text-center sm:text-left">
              <div className="inline-flex items-center gap-2 text-primary font-code text-[10px] font-bold tracking-widest uppercase mb-1">
                <Sparkles className="w-3 h-3" /> Live Campus Catalog
              </div>
              <h2 className="font-headline text-3xl font-black leading-tight tracking-tight">
                Current <span className="text-primary">Marketplace</span>
              </h2>
            </div>

            <div className="relative">
              <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input 
                placeholder="Find Physics, Allen notes, HC Verma..." 
                className="pl-10 h-12 rounded-2xl bg-card/60 border-border focus:ring-primary shadow-sm"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>

            {isBooksLoading ? (
              <div className="flex flex-col items-center justify-center py-24 gap-4">
                <Loader2 className="w-8 h-8 animate-spin text-primary opacity-50" />
                <p className="text-[10px] text-muted-foreground font-bold uppercase tracking-widest">Syncing with Campus Servers...</p>
              </div>
            ) : filteredBooks.length === 0 ? (
              <div className="text-center py-24 bg-muted/20 rounded-[2rem] border border-dashed border-border">
                <div className="text-5xl mb-4">🔍</div>
                <p className="text-muted-foreground font-medium">No results found for "{searchQuery}"</p>
                <Button variant="link" onClick={() => setSearchQuery('')} className="text-primary font-bold">Clear filters</Button>
              </div>
            ) : (
              <div className="grid grid-cols-2 gap-4">
                {filteredBooks.map(book => (
                  <BookCard 
                    key={book.id} 
                    book={book} 
                    isWishlisted={wishlistIds.includes(book.id)}
                    onToggleWishlist={(e) => {
                      e.stopPropagation();
                      toggleWishlist(book);
                    }}
                    onClick={() => setSelectedBook(book)}
                  />
                ))}
              </div>
            )}
          </div>
        )}

        {activeTab === 'wishlist' && (
          <div className="space-y-6 animate-in fade-in slide-in-from-right-2 duration-300">
            <div>
              <h2 className="font-headline text-3xl font-black leading-tight tracking-tight">My <span className="text-primary">Saved</span> Items</h2>
              <p className="text-xs text-muted-foreground font-bold uppercase tracking-wider">{wishlistIds.length} books in your list</p>
            </div>
            {!wishlistData || wishlistData.length === 0 ? (
              <div className="text-center py-32 bg-muted/20 rounded-[2rem] border border-dashed border-border">
                <div className="text-6xl mb-6">🏷️</div>
                <p className="text-muted-foreground font-medium mb-6">Your wishlist is empty</p>
                <Button className="rounded-2xl bg-primary text-white font-bold h-12 px-8" onClick={() => setActiveTab('browse')}>Go Shopping</Button>
              </div>
            ) : (
              <div className="grid grid-cols-2 gap-4">
                {wishlistData.map(book => (
                  <BookCard 
                    key={book.id} 
                    book={book} 
                    isWishlisted={true}
                    onToggleWishlist={(e) => {
                      e.stopPropagation();
                      toggleWishlist(book);
                    }}
                    onClick={() => setSelectedBook(book)}
                  />
                ))}
              </div>
            )}
          </div>
        )}

        {activeTab === 'mybooks' && (
          <div className="space-y-6 animate-in fade-in slide-in-from-right-2 duration-300">
            <div>
              <h2 className="font-headline text-3xl font-black leading-tight tracking-tight">Active <span className="text-primary">Listings</span></h2>
              <p className="text-xs text-muted-foreground font-bold uppercase tracking-wider">Manage your items for sale</p>
            </div>
            
            {(!booksData || booksData.filter(b => b.sellerId === user.uid).length === 0) ? (
              <div className="text-center py-32 bg-muted/20 rounded-[2rem] border border-dashed border-border">
                <div className="text-6xl mb-6">📦</div>
                <p className="text-muted-foreground font-medium mb-8">You haven't listed any books yet</p>
                <Button className="rounded-2xl bg-primary text-white font-bold h-12 px-8 shadow-lg shadow-primary/20" onClick={() => setIsSellModalOpen(true)}>Post First Book</Button>
              </div>
            ) : (
              <div className="space-y-3">
                {booksData.filter(b => b.sellerId === user.uid).map(book => (
                  <div key={book.id} className="bg-card border border-border p-3 rounded-2xl flex gap-4 items-center shadow-sm hover:border-primary/30 transition-colors">
                    <div className="relative w-16 h-20 rounded-xl overflow-hidden shrink-0">
                      <Image src={book.imageUrl} alt={book.title} fill className="object-cover" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-bold text-sm truncate">{book.title}</p>
                      <p className="text-[10px] text-muted-foreground font-bold uppercase tracking-widest">₹{book.price} • {book.area}</p>
                    </div>
                    <Button 
                      variant="ghost" 
                      size="icon" 
                      className="text-muted-foreground hover:text-destructive hover:bg-destructive/5"
                      onClick={() => handleUnlist(book.id)}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {activeTab === 'profile' && (
          <div className="space-y-8 animate-in fade-in slide-in-from-right-2 duration-300">
            <div className="flex flex-col items-center text-center pt-8">
              <div className="relative mb-4">
                {user.photoURL ? (
                  <img src={user.photoURL} alt="Profile" className="w-28 h-28 rounded-[2rem] shadow-2xl shadow-primary/20 border-2 border-primary/20" />
                ) : (
                  <div className="w-28 h-28 rounded-[2rem] bg-primary/10 border-2 border-primary/20 flex items-center justify-center text-primary">
                    <UserCircle className="w-16 h-16" />
                  </div>
                )}
                {user.isAnonymous && (
                  <Badge className="absolute -bottom-2 right-0 bg-amber-500 text-white border-4 border-background rounded-lg text-[10px] font-black">GUEST</Badge>
                )}
              </div>
              <h2 className="font-headline text-3xl font-black tracking-tight">{user.displayName || (user.isAnonymous ? 'Guest Student' : 'Verified Member')}</h2>
              <p className="text-muted-foreground text-xs font-code mt-1">{user.email || 'No email associated'}</p>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="bg-card border border-border p-8 rounded-[2rem] text-center shadow-sm">
                <p className="text-4xl font-black text-primary">
                  {booksData?.filter(b => b.sellerId === user.uid).length || 0}
                </p>
                <p className="text-[10px] text-muted-foreground uppercase font-black tracking-widest mt-2">Active Listings</p>
              </div>
              <div className="bg-card border border-border p-8 rounded-[2rem] text-center shadow-sm">
                <p className="text-4xl font-black text-primary">
                  {wishlistIds.length}
                </p>
                <p className="text-[10px] text-muted-foreground uppercase font-black tracking-widest mt-2">Wishlist Items</p>
              </div>
            </div>

            {user.isAnonymous && (
              <div className="p-6 bg-amber-500/10 border border-amber-500/20 rounded-[2rem] space-y-3">
                <p className="text-xs font-bold text-amber-500 uppercase tracking-widest text-center">Security Notice</p>
                <p className="text-xs text-amber-200/70 text-center leading-relaxed">
                  You are using a Guest account. Your data may be lost if you clear your browser cache. 
                  Sign in with Google to secure your listings.
                </p>
                <Button 
                  className="w-full bg-amber-500 hover:bg-amber-600 text-white font-bold rounded-xl h-11"
                  onClick={() => initiateGoogleSignIn(auth)}
                >
                  Link Google Account
                </Button>
              </div>
            )}

            <Button 
              variant="outline" 
              className="w-full rounded-2xl h-14 font-black text-muted-foreground border-border hover:bg-destructive/5 hover:text-destructive hover:border-destructive/20 transition-all"
              onClick={() => auth.signOut()}
            >
              Sign Out from Account
            </Button>
          </div>
        )}
      </main>

      <BookDetailModal 
        book={selectedBook}
        onClose={() => setSelectedBook(null)}
        isWishlisted={selectedBook ? wishlistIds.includes(selectedBook.id) : false}
        onToggleWishlist={() => selectedBook && toggleWishlist(selectedBook)}
        onChat={() => setIsChatOpen(true)}
        onCall={() => {
          if (selectedBook?.sellerPhone) {
            window.location.href = `tel:${selectedBook.sellerPhone}`;
          } else {
            toast({ title: "No Number", description: "Seller hasn't provided a contact number." });
          }
        }}
      />

      <SellBookModal 
        isOpen={isSellModalOpen} 
        onClose={() => setIsSellModalOpen(false)}
        onSubmit={() => {
          setIsSellModalOpen(false);
          setActiveTab('mybooks');
        }}
      />

      <ChatModal 
        book={selectedBook}
        isOpen={isChatOpen}
        onClose={() => setIsChatOpen(false)}
      />

      <BottomNav activeTab={activeTab} onTabChange={setActiveTab} />
    </div>
  );
}
