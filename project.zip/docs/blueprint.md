# **App Name**: StudentExchange

## Core Features:

- Book Browsing and Filtering: Browse available books with options to filter by subject, exam type, and condition, as well as search by title or seller.
- Book Detail View: View comprehensive details for each book, including price, seller information, and contact options.
- Personal Wishlist: Allow users to save books of interest to a personal wishlist for later review.
- Book Listing: Enable users to easily list their own books for sale with details such as title, subject, price, and condition. These listings are persisted to a database.
- AI-Powered Description Tool: Utilize a generative AI tool to suggest concise and engaging descriptions for books when a user creates a new listing, based on the book's title and subject.
- Seller Contact Module: Provide a simple interface to mock communication between buyer and seller, showcasing how direct contact for meeting arrangements would function.
- User Profile and Listings: A dedicated section for users to manage their active listings and review their saved books.

## Style Guidelines:

- Dark color scheme. Primary UI elements use a warm, inviting orange (#FF891A). The background features a very dark, subtly nuanced shade (#1D1917) providing depth without distraction. An accent color of soft reddish-pink (#F3738E) is reserved for highlighting important interactive elements or secondary actions, creating visual interest.
- Headlines and prominent text elements use 'Space Grotesk', a sans-serif with a modern, tech-inspired feel. Body text and longer descriptions use 'Inter', a neutral and highly readable sans-serif. Utility text, like dates or status, uses 'Source Code Pro', a monospace font for clear distinction.
- Leverage a set of consistent and expressive emoji icons for quick visual understanding and to maintain a friendly, student-centric aesthetic across the app, such as 📚 for books or 🔍 for search.
- The layout is clean, mobile-first, and highly intuitive, emphasizing content with card-based display for book listings and detailed views. Key navigation is easily accessible via a persistent bottom bar. Generous padding and clear hierarchy ensure a user-friendly experience.
- Subtle and fluid micro-interactions, such as smooth hover effects on interactive elements, seamless modal transitions, and discrete toast notifications, to provide responsive feedback and enhance overall user engagement without being overly distracting.